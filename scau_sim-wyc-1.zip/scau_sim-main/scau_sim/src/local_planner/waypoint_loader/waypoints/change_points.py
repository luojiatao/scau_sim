import csv

# 输入文件名和输出文件名
input_file = "waypoints_origin.csv"
output_file = "waypoints.csv"

# 打开输入文件和输出文件
with open(input_file, 'r', newline='') as csvfile, open(output_file, 'w', newline='') as outfile:
    # 创建CSV读取器和写入器
    reader = csv.reader(csvfile)
    writer = csv.writer(outfile)

    # 处理每一行数据
    for row in reader:
        if len(row) > 0 and row[0].replace(".", "", 1).replace("-", "", 1).isdigit():
            # 将第一列的数字加上17.5
            original_value = float(row[0])
            new_value = original_value + 17.5
            row[0] = str(new_value)

        # 将处理后的行写入输出文件
        writer.writerow(row)

print(f"文件'{input_file}'已经处理并保存为'{output_file}'")
